function start() {
  var button = document.querySelector('#button');
  button.addEventListener('click', handleMegaSena);
}

function handleMegaSena() {
  fetch('http://localhost:3001/megasena').then(function (resource) {
    resource.json().then(function (json) {
      var div = document.querySelector('#numbers');
      div.textContent = json.join(', ');
    });
  });
}

start();

var express = require('express');
var cors = require('cors');
var app = express();
app.use(cors());

app.get('/', function (request, response) {
  response.json({ message: 'Acesse /megasena' });
});

function getRandomNumber(from, to) {
  return Math.floor(Math.random() * (60 - 1 + 1)) + 1;
}

app.get('/megasena', function (request, response) {
  var numbers = [];

  while (numbers.length < 6) {
    var newNumber = getRandomNumber(1, 60);

    if (!numbers.includes(numbers)) {
      numbers.push(newNumber);
    } else {
      console.log(newNumber + ' já existe');
    }
  }

  response.json(
    numbers.sort(function (a, b) {
      return a - b;
      // if (a > b) {
      //   return 1;
      // }

      // if (a < b) {
      //   return -1;
      // }

      // return 0;
    })
  );
});

app.listen(3001, function () {
  console.log('Servidor iniciado na porta 3001');
});
